﻿namespace Grzymska.EpicFootwear.Core
{
    public enum ShoeType
    { 
        Boots,
        Sneakers,
        Sport,
        Heels,
        Sandals
    }
}
